#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef void (*luau_output_cb)(int32_t kind, const char* message);
int32_t luau_bridge_run(const char* source, luau_output_cb cb,
                        int32_t timeout_ms, int64_t max_memory_bytes);
#ifdef __cplusplus
}
#endif
