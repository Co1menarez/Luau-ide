#include "luau_bridge.h"
#include "lua.h"
#include "lualib.h"
#include "luacode.h"
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <string>

namespace {
struct RunContext {
    luau_output_cb cb;
    std::chrono::steady_clock::time_point deadline;
    int64_t maxMemory;
    int64_t usedMemory;
    bool timedOut;
};

void* limitedAlloc(void* ud, void* ptr, size_t osize, size_t nsize) {
    auto* ctx = static_cast<RunContext*>(ud);
    if (nsize == 0) {
        if (ptr) ctx->usedMemory -= (int64_t)osize;
        free(ptr);
        return nullptr;
    }
    int64_t delta = (int64_t)nsize - (ptr ? (int64_t)osize : 0);
    if (ctx->usedMemory + delta > ctx->maxMemory) return nullptr;
    void* np = realloc(ptr, nsize);
    if (np) ctx->usedMemory += delta;
    return np;
}

void interruptCb(lua_State* L, int gc) {
    if (gc >= 0) return;
    auto* ctx = static_cast<RunContext*>(lua_callbacks(L)->userdata);
    if (ctx && std::chrono::steady_clock::now() > ctx->deadline) {
        ctx->timedOut = true;
        luaL_error(L, "tiempo de ejecucion excedido (posible bucle infinito)");
    }
}

void emit(lua_State* L, int kind, const std::string& msg) {
    auto* ctx = static_cast<RunContext*>(lua_callbacks(L)->userdata);
    if (ctx && ctx->cb) ctx->cb(kind, msg.c_str());
}

std::string joinArgs(lua_State* L) {
    int n = lua_gettop(L);
    std::string out;
    for (int i = 1; i <= n; i++) {
        size_t len;
        const char* s = luaL_tolstring(L, i, &len);
        if (i > 1) out += '\t';
        out.append(s, len);
        lua_pop(L, 1);
    }
    return out;
}

int l_print(lua_State* L) { emit(L, 0, joinArgs(L)); return 0; }
int l_warn(lua_State* L) { emit(L, 1, joinArgs(L)); return 0; }
} // namespace

extern "C" int32_t luau_bridge_run(const char* source, luau_output_cb cb,
                                   int32_t timeout_ms, int64_t max_memory_bytes) {
    RunContext ctx{cb,
                   std::chrono::steady_clock::now() + std::chrono::milliseconds(timeout_ms),
                   max_memory_bytes, 0, false};

    lua_State* L = lua_newstate(limitedAlloc, &ctx);
    if (!L) { if (cb) cb(2, "No se pudo crear el estado de Luau"); return 1; }

    lua_callbacks(L)->userdata = &ctx;
    lua_callbacks(L)->interrupt = interruptCb;

    luaL_openlibs(L);
    static const char* blocked[] = {"os", "debug", "dofile", "loadfile", "require", "collectgarbage"};
    for (const char* name : blocked) { lua_pushnil(L); lua_setglobal(L, name); }

    lua_pushcfunction(L, l_print, "print"); lua_setglobal(L, "print");
    lua_pushcfunction(L, l_warn, "warn");   lua_setglobal(L, "warn");

    luaL_sandbox(L);
    luaL_sandboxthread(L);

    int32_t result = 0;
    size_t bytecodeSize = 0;
    lua_CompileOptions opts = {};
    opts.optimizationLevel = 1;
    opts.debugLevel = 1;
    char* bytecode = luau_compile(source, strlen(source), &opts, &bytecodeSize);

    if (luau_load(L, "=script", bytecode, bytecodeSize, 0) != 0) {
        size_t n;
        const char* err = lua_tolstring(L, -1, &n);
        emit(L, 2, std::string("Error de sintaxis: ") + (err ? std::string(err, n) : "desconocido"));
        result = 2;
    } else if (lua_pcall(L, 0, 0, 0) != LUA_OK) {
        size_t n;
        const char* err = lua_tolstring(L, -1, &n);
        std::string msg = err ? std::string(err, n) : "error desconocido";
        emit(L, 2, std::string(ctx.timedOut ? "Timeout: " : "Error de ejecucion: ") + msg);
        result = ctx.timedOut ? 3 : 4;
    }

    free(bytecode);
    lua_close(L);
    return result;
}
