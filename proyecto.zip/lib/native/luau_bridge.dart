import 'dart:ffi';
import 'dart:io';
import 'dart:isolate';
import 'package:ffi/ffi.dart';

typedef _OutputCbNative = Void Function(Int32 kind, Pointer<Utf8> msg);
typedef _RunNative = Int32 Function(Pointer<Utf8> src,
    Pointer<NativeFunction<_OutputCbNative>> cb, Int32 timeoutMs, Int64 maxMem);
typedef _RunDart = int Function(Pointer<Utf8> src,
    Pointer<NativeFunction<_OutputCbNative>> cb, int timeoutMs, int maxMem);

enum OutputKind { print, warn, error }

class OutputLine {
  final OutputKind kind;
  final String text;
  OutputLine(this.kind, this.text);
}

class LuauRunner {
  Isolate? _isolate;

  Stream<OutputLine> run(String source,
      {int timeoutMs = 3000, int maxMemMb = 64}) async* {
    final port = ReceivePort();
    _isolate = await Isolate.spawn(
      _entry,
      _Job(port.sendPort, source, timeoutMs, maxMemMb * 1024 * 1024),
      onExit: port.sendPort,
    );
    await for (final msg in port) {
      if (msg == null) break;
      final m = msg as List;
      yield OutputLine(OutputKind.values[m[0] as int], m[1] as String);
    }
    port.close();
    _isolate = null;
  }

  void kill() {
    _isolate?.kill(priority: Isolate.immediate);
  }
}

class _Job {
  final SendPort port;
  final String src;
  final int timeoutMs, maxMem;
  _Job(this.port, this.src, this.timeoutMs, this.maxMem);
}

SendPort? _outPort;

void _onOutput(int kind, Pointer<Utf8> msg) {
  _outPort?.send([kind, msg.toDartString()]);
}

void _entry(_Job job) {
  _outPort = job.port;
  try {
    final lib = Platform.isAndroid
        ? DynamicLibrary.open('libluau_bridge.so')
        : DynamicLibrary.process();
    final run = lib.lookupFunction<_RunNative, _RunDart>('luau_bridge_run');
    final src = job.src.toNativeUtf8();
    final cb = Pointer.fromFunction<_OutputCbNative>(_onOutput);
    final code = run(src, cb, job.timeoutMs, job.maxMem);
    malloc.free(src);
    if (code != 0) job.port.send([2, '[proceso termino con codigo $code]']);
  } catch (e) {
    job.port.send([2, 'Error del puente nativo: $e']);
  }
  job.port.send(null);
}
