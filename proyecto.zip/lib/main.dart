import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'ui/editor_page.dart';

void main() => runApp(const ProviderScope(child: LuauIdeApp()));

class LuauIdeApp extends StatelessWidget {
  const LuauIdeApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Luau IDE',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true),
        home: const EditorPage(),
      );
}
