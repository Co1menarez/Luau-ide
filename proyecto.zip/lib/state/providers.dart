import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../native/luau_bridge.dart';

const defaultCode = '''-- Bienvenido a Luau IDE
local function fib(n)
    if n < 2 then return n end
    return fib(n - 1) + fib(n - 2)
end

for i = 1, 10 do
    print("fib(" .. i .. ") =", fib(i))
end
warn("esto es una advertencia")
''';

final currentFileProvider = StateProvider<String?>((ref) => null);

class ConsoleNotifier extends StateNotifier<List<OutputLine>> {
  ConsoleNotifier() : super([]);
  void add(OutputLine l) => state = [...state, l];
  void clear() => state = [];
}

final consoleProvider =
    StateNotifierProvider<ConsoleNotifier, List<OutputLine>>((ref) => ConsoleNotifier());
final runnerProvider = Provider((ref) => LuauRunner());
final runningProvider = StateProvider<bool>((ref) => false);
