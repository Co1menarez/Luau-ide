import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../native/luau_bridge.dart';
import '../state/providers.dart';

class ConsolePanel extends ConsumerWidget {
  const ConsolePanel({super.key});

  Color _color(OutputKind k) => switch (k) {
        OutputKind.print => const Color(0xFFD4D4D4),
        OutputKind.warn => const Color(0xFFFFCC00),
        OutputKind.error => const Color(0xFFF44747),
      };

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lines = ref.watch(consoleProvider);
    return Container(
      color: const Color(0xFF111111),
      child: Column(children: [
        Container(
          color: const Color(0xFF252526),
          padding: const EdgeInsets.symmetric(horizontal: 12),
          height: 32,
          child: Row(children: [
            const Text('SALIDA', style: TextStyle(color: Colors.grey, fontSize: 12)),
            const Spacer(),
            IconButton(
              iconSize: 18,
              padding: EdgeInsets.zero,
              icon: const Icon(Icons.delete_outline, color: Colors.grey),
              onPressed: () => ref.read(consoleProvider.notifier).clear(),
            ),
          ]),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(8),
            itemCount: lines.length,
            itemBuilder: (_, i) => SelectableText(
              lines[i].text,
              style: TextStyle(
                  fontFamily: 'monospace', fontSize: 13, color: _color(lines[i].kind)),
            ),
          ),
        ),
      ]),
    );
  }
}
