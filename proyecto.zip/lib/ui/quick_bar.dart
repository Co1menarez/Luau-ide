import 'package:flutter/material.dart';

class QuickBar extends StatelessWidget {
  final TextEditingController controller;
  const QuickBar({super.key, required this.controller});

  static const _symbols = [
    '{', '}', '(', ')', '[', ']', '==', '~=', '=', '"', "'", '.', ':', ',', '#',
    'end', 'then', 'function', 'local', 'if', 'for', 'do', 'return',
  ];

  void _insert(String s) {
    final t = controller.text;
    final sel = controller.selection;
    final start = sel.isValid ? sel.start : t.length;
    final end = sel.isValid ? sel.end : t.length;
    final pad = RegExp(r'^[a-z]{2,}$').hasMatch(s) ? ' ' : '';
    final ins = s + pad;
    controller.value = TextEditingValue(
      text: t.replaceRange(start, end, ins),
      selection: TextSelection.collapsed(offset: start + ins.length),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 44,
      color: const Color(0xFF2D2D2D),
      child: ListView(scrollDirection: Axis.horizontal, children: [
        _btn('TAB', () => _insert('  ')),
        for (final s in _symbols) _btn(s, () => _insert(s)),
      ]),
    );
  }

  Widget _btn(String label, VoidCallback onTap) => InkWell(
        onTap: onTap,
        child: Container(
          alignment: Alignment.center,
          constraints: const BoxConstraints(minWidth: 40),
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Text(label,
              style: const TextStyle(
                  color: Colors.white, fontFamily: 'monospace', fontSize: 16)),
        ),
      );
}
