import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../state/providers.dart';
import '../storage/script_store.dart';
import 'code_editor.dart';
import 'console_panel.dart';
import 'file_manager.dart';
import 'quick_bar.dart';

class EditorPage extends ConsumerStatefulWidget {
  const EditorPage({super.key});
  @override
  ConsumerState<EditorPage> createState() => _EditorPageState();
}

class _EditorPageState extends ConsumerState<EditorPage> {
  final _ctrl = LuauHighlightController();
  final _store = ScriptStore();

  @override
  void initState() {
    super.initState();
    _ctrl.text = defaultCode;
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    final console = ref.read(consoleProvider.notifier);
    final runner = ref.read(runnerProvider);
    ref.read(runningProvider.notifier).state = true;
    console.clear();
    await for (final line in runner.run(_ctrl.text)) {
      console.add(line);
    }
    ref.read(runningProvider.notifier).state = false;
  }

  Future<void> _save() async {
    var name = ref.read(currentFileProvider);
    if (name == null) {
      final c = TextEditingController(text: 'mi_script.luau');
      name = await showDialog<String>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Nombre del archivo'),
          content: TextField(controller: c, autofocus: true),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
            TextButton(
                onPressed: () => Navigator.pop(ctx, c.text),
                child: const Text('Guardar')),
          ],
        ),
      );
      if (name == null || name.trim().isEmpty) return;
    }
    final saved = await _store.save(name, _ctrl.text);
    if (!mounted) return;
    ref.read(currentFileProvider.notifier).state = saved;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text('Guardado: $saved')));
  }

  @override
  Widget build(BuildContext context) {
    final running = ref.watch(runningProvider);
    final file = ref.watch(currentFileProvider);
    return Scaffold(
      backgroundColor: const Color(0xFF1E1E1E),
      drawer: FileManagerDrawer(
        store: _store,
        onOpen: (name, content) {
          _ctrl.text = content;
          ref.read(currentFileProvider.notifier).state = name;
        },
      ),
      appBar: AppBar(
        title: Text(file ?? 'sin titulo.luau', style: const TextStyle(fontSize: 16)),
        actions: [
          IconButton(
            icon: const Icon(Icons.note_add_outlined),
            onPressed: () {
              _ctrl.text = '';
              ref.read(currentFileProvider.notifier).state = null;
            },
          ),
          IconButton(icon: const Icon(Icons.save), onPressed: _save),
          if (running)
            IconButton(
              icon: const Icon(Icons.stop_circle, color: Colors.redAccent),
              onPressed: () => ref.read(runnerProvider).kill(),
            )
          else
            IconButton(
                icon: const Icon(Icons.play_arrow, color: Colors.greenAccent),
                onPressed: _run),
        ],
      ),
      body: Column(children: [
        Expanded(flex: 3, child: CodeEditor(controller: _ctrl)),
        QuickBar(controller: _ctrl),
        const Expanded(flex: 2, child: ConsolePanel()),
      ]),
    );
  }
}
