import 'package:flutter/material.dart';

class LuauHighlightController extends TextEditingController {
  static const _keywords = {
    'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for', 'function',
    'if', 'in', 'local', 'nil', 'not', 'or', 'repeat', 'return', 'then', 'true',
    'until', 'while', 'continue', 'export', 'type'
  };

  static final _token = RegExp(
    r'(--\[\[[\s\S]*?\]\]|--[^\n]*)'
    r'|("(?:\\.|[^"\\])*"|' r"'(?:\\.|[^'\\])*'" r'|\[\[[\s\S]*?\]\])'
    r'|(\b\d+(?:\.\d+)?\b)'
    r'|([A-Za-z_][A-Za-z0-9_]*)',
  );

  @override
  TextSpan buildTextSpan(
      {required BuildContext context, TextStyle? style, required bool withComposing}) {
    final text = this.text;
    final spans = <TextSpan>[];
    var last = 0;
    for (final m in _token.allMatches(text)) {
      if (m.start > last) spans.add(TextSpan(text: text.substring(last, m.start)));
      Color? color;
      if (m.group(1) != null) {
        color = const Color(0xFF6A9955);
      } else if (m.group(2) != null) {
        color = const Color(0xFFCE9178);
      } else if (m.group(3) != null) {
        color = const Color(0xFFB5CEA8);
      } else if (m.group(4) != null) {
        final w = m.group(4)!;
        if (_keywords.contains(w)) {
          color = const Color(0xFF569CD6);
        } else if (w == 'print' || w == 'warn') {
          color = const Color(0xFFDCDCAA);
        }
      }
      spans.add(TextSpan(
          text: m.group(0), style: color != null ? TextStyle(color: color) : null));
      last = m.end;
    }
    if (last < text.length) spans.add(TextSpan(text: text.substring(last)));
    return TextSpan(style: style, children: spans);
  }
}

class CodeEditor extends StatefulWidget {
  final LuauHighlightController controller;
  const CodeEditor({super.key, required this.controller});
  @override
  State<CodeEditor> createState() => _CodeEditorState();
}

class _CodeEditorState extends State<CodeEditor> {
  final _vScroll = ScrollController();
  final _gutterScroll = ScrollController();
  static const _style = TextStyle(
      fontFamily: 'monospace', fontSize: 14, height: 1.4, color: Color(0xFFD4D4D4));

  @override
  void initState() {
    super.initState();
    _vScroll.addListener(() {
      if (_gutterScroll.hasClients) _gutterScroll.jumpTo(_vScroll.offset);
    });
    widget.controller.addListener(_onChange);
  }

  void _onChange() => setState(() {});

  @override
  void dispose() {
    widget.controller.removeListener(_onChange);
    _vScroll.dispose();
    _gutterScroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final lines = '\n'.allMatches(widget.controller.text).length + 1;
    return Container(
      color: const Color(0xFF1E1E1E),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(
          width: 44,
          child: ListView.builder(
            controller: _gutterScroll,
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.only(top: 12),
            itemCount: lines,
            itemBuilder: (_, i) => SizedBox(
              height: 14 * 1.4,
              child: Text('${i + 1}  ',
                  textAlign: TextAlign.right,
                  style: _style.copyWith(color: Colors.grey)),
            ),
          ),
        ),
        Expanded(
          child: SingleChildScrollView(
            controller: _vScroll,
            padding: const EdgeInsets.only(top: 12, right: 8, bottom: 80),
            child: TextField(
              controller: widget.controller,
              maxLines: null,
              keyboardType: TextInputType.multiline,
              autocorrect: false,
              enableSuggestions: false,
              style: _style,
              cursorColor: Colors.white,
              decoration:
                  const InputDecoration(border: InputBorder.none, isCollapsed: true),
            ),
          ),
        ),
      ]),
    );
  }
}
