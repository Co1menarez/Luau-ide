import 'package:flutter/material.dart';
import '../storage/script_store.dart';

class FileManagerDrawer extends StatefulWidget {
  final ScriptStore store;
  final void Function(String name, String content) onOpen;
  const FileManagerDrawer({super.key, required this.store, required this.onOpen});
  @override
  State<FileManagerDrawer> createState() => _FileManagerDrawerState();
}

class _FileManagerDrawerState extends State<FileManagerDrawer> {
  late Future<List<String>> _files = widget.store.list();
  void _refresh() => setState(() => _files = widget.store.list());

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: SafeArea(
        child: Column(children: [
          const ListTile(
              title: Text('Mis scripts', style: TextStyle(fontWeight: FontWeight.bold))),
          Expanded(
            child: FutureBuilder<List<String>>(
              future: _files,
              builder: (_, snap) {
                final files = snap.data ?? [];
                if (files.isEmpty) {
                  return const Center(child: Text('Sin scripts guardados'));
                }
                return ListView(children: [
                  for (final f in files)
                    ListTile(
                      leading: const Icon(Icons.description_outlined),
                      title: Text(f),
                      onTap: () async {
                        final c = await widget.store.read(f);
                        widget.onOpen(f, c);
                        if (context.mounted) Navigator.pop(context);
                      },
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          await widget.store.delete(f);
                          _refresh();
                        },
                      ),
                    ),
                ]);
              },
            ),
          ),
        ]),
      ),
    );
  }
}
