import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

class ScriptStore {
  Future<Directory> _dir() async {
    final base = await getApplicationDocumentsDirectory();
    final d = Directory(p.join(base.path, 'scripts'));
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  String _safe(String name) {
    var n = p.basename(name.trim());
    if (!n.endsWith('.luau') && !n.endsWith('.lua')) n = '$n.luau';
    return n;
  }

  Future<List<String>> list() async {
    final d = await _dir();
    final files = await d.list().where((e) => e is File).toList();
    final names = files
        .map((f) => p.basename(f.path))
        .where((n) => n.endsWith('.luau') || n.endsWith('.lua'))
        .toList()
      ..sort();
    return names;
  }

  Future<String> read(String name) async =>
      File(p.join((await _dir()).path, _safe(name))).readAsString();

  Future<String> save(String name, String content) async {
    final safe = _safe(name);
    await File(p.join((await _dir()).path, safe)).writeAsString(content);
    return safe;
  }

  Future<void> delete(String name) async =>
      File(p.join((await _dir()).path, _safe(name))).delete();
}
